// Función para validar el formulario
function validateForm() {
    let  email= document.getElementById('inputEmail').value;
    let name = document.getElementById('inputName').value;
    let apellido = document.getElementById('inputApellido').value;
    let phone = document.getElementById('inputPhone').value;
    let dni = document.getElementById('inputDni').value;
    let domicilio = document.getElementById('inputDomicilio').value;
    let carrera = document.getElementById('inputCarrera').value;

    if (email == "") {
        alert('Nombre requerido');
        return false;
    } 

    if (name == "") {
        alert('Apellido requerido');
        return false;
    }

    if (apellido == "") {
        alert('Email requerido');
        return false;
    }

    if (phone == "") {
        alert('Dni requerido');
        return false;
    }

    if (dni == "") {
        alert('Sueldo requerido');
        return false;
    }

    if (domicilio == "") {
        alert('Sexo requerido');
        return false;
    }

    if (carrera == "") {
        alert('Debe seleccionar un turno');
        return false;
    }

    alert('Empleado agregado exitosamente');
    return true;
}

// Función para mostrar los datos
function showData() {
    let listAdmin;

    if (localStorage.getItem('listAdmin') == null) {
        listAdmin = [];
    } else {
        listAdmin = JSON.parse(localStorage.getItem("listAdmin"));
    }

    var html = "";

    listAdmin.forEach(function(element, index2) {
        html += "<tr>";
        html += "<td>" + element.email + "</td>";
        html += "<td>" + element.name + "</td>";
        html += "<td>" + element.apellido + "</td>";
        html += "<td>" + element.phone + "</td>";
        html += "<td>" + element.dni + "</td>";
        html += "<td>" + element.domicilio + "</td>";
        html += "<td>" + element.carrera + "</td>";

        // Cambiar el color del botón "Eliminar dato" a rojo y el botón "Editar dato" a un verde más oscuro
        html += '<td><button onclick="deleteData(' + index2 + ')" class="btn" style="background-color: #FF0000; color: #FFF;">Eliminar</button> <button onclick="updateData(' + index2 + ')" class="btn" style="background-color: #008000; color: #FFF;">Editar</button></td>';
        html += "</tr>";
    });

    document.querySelector('#tableData tbody').innerHTML = html;
}



// Función para agregar datos
function AddData() {
    if (validateForm() == true) {
        let email = document.getElementById('inputEmail').value;
        let name = document.getElementById('inputName').value;
        let apellido = document.getElementById('inputApellido').value;
        let phone = document.getElementById('inputPhone').value;
        let dni = document.getElementById('inputDni').value;
        let domicilio = document.getElementById('inputDomicilio').value;
        let carrera = document.getElementById('inputCarrera').value;

        var listAdmin;
        if (localStorage.getItem('listAdmin') == null) {
            listAdmin = [];
        } else {
            listAdmin = JSON.parse(localStorage.getItem("listAdmin"));
        }

       
        

        listAdmin.push({
            email: email,
            name: name,
            apellido: apellido,
            phone: phone,
            dni: dni,
            domicilio: domicilio,
            carrera: carrera,
        });

        localStorage.setItem('listAdmin', JSON.stringify(listAdmin));

        showData();

        document.getElementById('inputEmail').value = "";
        document.getElementById('inputName').value = "";
        document.getElementById('inputApellido').value = "";
        document.getElementById('inputPhone').value = "";
        document.getElementById('inputDni').value = "";
        document.getElementById('inputDomicilio').value = "";
        document.getElementById('inputCarrera').value = "";
    }
}

// Función para eliminar datos
function deleteData(index2) {
    var listAdmin;
    if (localStorage.getItem('listAdmin') == null) {
        listAdmin = [];
    } else {
        listAdmin = JSON.parse(localStorage.getItem("listAdmin"));
    }

    listAdmin.splice(index2, 1);
    localStorage.setItem('listAdmin', JSON.stringify(listAdmin));
    showData();
}

// Función para actualizar datos
function updateData(index2) {
    document.getElementById("btnAdd").style.display = 'none';
    document.getElementById("btnUpdate").style.display = 'block';

    var listAdmin;
    if (localStorage.getItem('listAdmin') == null) {
        listAdmin = [];
    } else {
        listAdmin = JSON.parse(localStorage.getItem("listAdmin"));
    }

    document.getElementById('inputEmail').value = listAdmin[index2].email;
    document.getElementById('inputName').value = listAdmin[index2].name;
    document.getElementById('inputApellido').value = listAdmin[index2].apellido;
    document.getElementById('inputPhone').value = listAdmin[index2].phone;
    document.getElementById('inputDni').value = listAdmin[index2].dni;
    document.getElementById('inputDomicilio').value = listAdmin[index2].domicilio;
    document.getElementById('inputCarrera').value = listAdmin[index2].carrera;

    document.querySelector("#btnUpdate").onclick = function () {
        if (validateForm() == true) {
            listAdmin[index2].email = document.getElementById('inputEmail').value;
            listAdmin[index2].name = document.getElementById('inputName').value;
            listAdmin[index2].apellido = document.getElementById('inputApellido').value;
            listAdmin[index2].phone = document.getElementById('inputPhone').value;
            listAdmin[index2].dni = document.getElementById('inputDni').value;
            listAdmin[index2].domicilio = document.getElementById('inputDomicilio').value;
            listAdmin[index2].carrera = document.getElementById('inputCarrera').value;

            localStorage.setItem('listAdmin', JSON.stringify(listAdmin));
            showData();

            document.getElementById('inputEmail').value = "";
            document.getElementById('inputName').value = "";
            document.getElementById('inputApellido').value = "";
            document.getElementById('inputPhone').value = "";
            document.getElementById('inputDni').value = "";
            document.getElementById('inputDomicilio').value = "";
            document.getElementById('inputCarrera').value = "";

            document.getElementById("btnAdd").style.display = 'block';
            document.getElementById("btnUpdate").style.display = 'none';
        }
    };
}

// Llamar a la función showData al cargar el documento
document.addEventListener("DOMContentLoaded", showData);
